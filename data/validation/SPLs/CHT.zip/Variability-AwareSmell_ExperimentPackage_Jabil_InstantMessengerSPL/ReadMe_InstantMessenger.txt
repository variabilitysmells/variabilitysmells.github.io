Segue a lista dos arquivos a serem inspecionados no projeto Instant Messenger:


 - InstantMessenger Feature Model (.pdf ou .jpg) (Modelo de feature)

 - EnumOrdenacao.java (pasta: /src/br/com/message/enums)

 - ContatoFacadeImpl.java (pasta: /src/br/com/message/facade)

 - FComentario.java (pasta: /src/br/com/message/features) - FContato.java (pasta: /src/br/com/message/features) - FGrupo.java (pasta: /src/br/com/message/features) - FMensagem.java (pasta: /src/br/com/message/features) - FMenuPrincipal.java (pasta: /src/br/com/message/features) - FRecuperarSenha.java (pasta: /src/br/com/message/features)