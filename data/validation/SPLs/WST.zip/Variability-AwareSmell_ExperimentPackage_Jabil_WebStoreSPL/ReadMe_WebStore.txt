Segue a lista dos arquivos a serem inspecionados no projeto WebStore SPL:

 - WebStore Feature Model (.pdf ou .jpg) (Modelo de features)

 - GenericDao.java (pasta: /src/br/com/webstore/dao)

 - GenericFacade.java (pasta: /src/br/com/webstore/facade)

 - EmbrulharPresente.java (pasta: /src/br/com/webstore/features)
 - UsuarioComumEdicao.java (pasta: /src/br/com/webstore/features)

 - WebStoreEventMainScreenP.java (pasta: /src/br/com/webstore/views)