package br.com.webstore.views;

import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import br.com.webstore.facade.GenericFacade;
//#if ${Comunicacao} == "T"
//#if ${BugTrack} == "T"
import br.com.webstore.features.BugTrackView;
//#if ${CarrinhoCompras} == "T"
import br.com.webstore.features.CarrinhoCheckout;
//#endif
//#if ${Categoria} == "T"
import br.com.webstore.features.CategoriaP;
//#endif
//#if ${FaleConosco} == "T"
import br.com.webstore.features.FaleConoscoView;
//#endif
//#endif
//#endif
//#if ${FAQ} == "T"
//import br.com.webstore.features.FAQ;
//#if  ${FAQListar} == "T"
import br.com.webstore.features.FaqListar;
//#endif
import br.com.webstore.features.FaqPesquisa;
//#endif
//#endif
//#if ${Produto} == "T"
import br.com.webstore.features.ProdutoPesquisa;
//#if ${Usuario} == "T"
import br.com.webstore.features.UsuarioComumEdicao;
//#endif
//#endif
//#if ${Usuario} == "T"
//import br.com.webstore.features.UsuarioInclusaoEdicao;
import br.com.webstore.features.UsuarioPesquisa;
import br.com.webstore.model.Usuario;

/**
 * @author webstore
 *
 */
public class WebStoreEventMainScreenP extends JFrame {

	/**
	 * Serial version id
	 */
	private static final long serialVersionUID = -2884618217124578987L;

	private static final String APPLICATION_NAME = "WebStore";
	
	private static final int WIDTH_SCREEN = 600;
	private static final int HEIGHT_SCREEN = 400;
	
	//#if ${Usuario} == "T"
	static List<Usuario> user = null;
	//#endif
	//public int posTab = 0;
	private static WebStoreEventMainScreenP instance;
	private JPanel contentPane;
	//#if ${Usuario} == "T"
	public static WebStoreEventMainScreenP getInstance(GenericFacade gfacade, Usuario usuarioLogado){
		if(instance == null)
			instance = new WebStoreEventMainScreenP(gfacade, usuarioLogado);
		
		return instance;
	}
	//#endif
	
	//#if ${Usuario} == "T"
	public WebStoreEventMainScreenP(GenericFacade gfacade, Usuario usuarioLogado) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane panelTab = new JTabbedPane();
		
		addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosing(WindowEvent e)
            {
                System.out.println("Closed");
                e.getWindow().dispose();
            }
        });
		
		//#if ${Usuario} == "T"

			panelTab.addTab(UsuarioPesquisa.NAME, new UsuarioPesquisa(gfacade));
		//#endif
		

			panelTab.addTab(UsuarioComumEdicao.NAME, new UsuarioComumEdicao(usuarioLogado.getId()));
		
		//#if ${Categoria} == "T"
			panelTab.addTab(CategoriaP.NAME, new CategoriaP(gfacade));
		//#endif
		
		
		//#if ${Comunicacao} == "T"
		//#if ${FAQ} == "T"
		//#if  ${FAQListar} == "T"
		panelTab.addTab(FaqListar.NAME, new FaqListar(gfacade));
		//#endif
		//#endif
		//#if ${BugTrack} == "T"
		if (usuarioLogado!=null)
			panelTab.addTab(BugTrackView.NAME, new BugTrackView(gfacade,usuarioLogado));
		//#endif
		
		//#if ${FAQ} == "T"
			panelTab.addTab(FaqPesquisa.NAME, new FaqPesquisa(gfacade));
		//#endif
				
		//#if ${FaleConosco} == "T"
		if (usuarioLogado!=null)
			panelTab.addTab(FaleConoscoView.NAME, new FaleConoscoView(usuarioLogado));
		//#endif
		//#endif

		/*panelTab.addTab("Ver Produto", new ProdutoView(gfacade, usuarioLogado));*/

		
		//#if ${CarrinhoCompras} == "T"
		panelTab.addTab(CarrinhoCheckout.NAME, CarrinhoCheckout.getInstance(gfacade, usuarioLogado));
		//#endif
		
		//#if ${Produto} == "T"
		if (usuarioLogado!=null)
			panelTab.addTab(ProdutoPesquisa.NAME, new ProdutoPesquisa(gfacade,usuarioLogado));
		//#endif
		
		
		
				
		//Init the selected tab
		panelTab.setSelectedIndex(0);
		
		//Create a grid layout with 1 column and 1 row
		setLayout(new GridLayout(1, 1));
		
		//Setter tabs in the main panel
		add(panelTab);
		
		//panelTab.setSelectedIndex(posTab);
	}//#endif
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GenericFacade gfacade = new GenericFacade();
				    List<Usuario> user = gfacade.getUsuarioByLoginSenha("Admin");
					WebStoreEventMainScreenP frame = new WebStoreEventMainScreenP(gfacade,user.get(0));
					//frame.getContentPane().setSize(800,400);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		//#if ${Usuario} == "T"
		//webStoreEventLogar(gfacade);
		//#endif
	}
	//#if ${Usuario} == "T"
//	public static void webStoreEventLogar(final GenericFacade gfacade){
//		final JDialog dlgLogin = new JDialog();
//		
//		dlgLogin.setModal(true);
//		dlgLogin.setTitle("Entrar no sistema WebStore");
//		dlgLogin.setResizable(false);
//		dlgLogin.setBounds(0, 0, 460, 320);
//		dlgLogin.setLocationRelativeTo(null);
//		final JTextField login = new JTextField(10);
//		JPanel panel = new JPanel();
//		panel.add(new JLabel("Nome Usuario"));
//	    panel.add(login);
       //Controle Acesso	    panel.add(new JLabel("*Senha:"));

	  //Controle Acesso	    final JPasswordField senha = new JPasswordField(10);
	  //Controle Acesso	    panel.add(senha);	
		
//		JButton btnLogar = new JButton("Entrar");
//		
//		btnLogar.setBounds(6, 85, 89, 23);
//		btnLogar.addActionListener(new java.awt.event.ActionListener() {
//			@SuppressWarnings({ "deprecation" })
//			@Override
//			public void actionPerformed(ActionEvent e) {
				//Controle Acessoif(login.getText().length()==0 || senha.getPassword().toString().length()==0){
				//Controle Acesso	JOptionPane.showMessageDialog(null, "Campos com * sao obrigatorios.");
				//Controle Acesso}
				//Controle Acessoelse{
					
					//#if ${Usuario} == "T"
				//Controle Acesso
				//user = gfacade.getUsuarioByLoginSenha(login.getText(), senha.getText());
//				user = gfacade.getUsuarioByLoginSenha(login.getText());
//					
//					if (!user.isEmpty()){
//						dlgLogin.setVisible(false);
//						user = gfacade.getUsuarioByLoginSenha("Admin");
//						
//						WebStoreEventMainScreenP mainScreen = new WebStoreEventMainScreenP(gfacade,user.get(0));
//						
//						mainScreen.getMainFrame().addWindowListener(new WindowAdapter() {
//							public void windowClosing(WindowEvent e) {
//								System.exit(0);
//							}
//						});
//						
//						mainScreen.getMainFrame().getContentPane().add(mainScreen,BorderLayout.CENTER);
//						mainScreen.getMainFrame().setSize(WIDTH_SCREEN, HEIGHT_SCREEN);
//						mainScreen.getMainFrame().setVisible(true);
//						mainScreen.getMainFrame().setLocationRelativeTo(null);
//					}
//					else{
//						JOptionPane.showMessageDialog(null, "Usuario " + login.getText() + " nao encontrado ou usuario e senha incorretos!");
//					}
//					//#endif
//				}
			//Controle Acesso}
//		});
//		
//		JButton btnCadastrar = new JButton("Cadastrar-se");
//		
//		btnCadastrar.setBounds(6, 108, 89, 23);
//		btnCadastrar.addActionListener(new java.awt.event.ActionListener() 
//		{
//			@Override
//			public void actionPerformed(ActionEvent e) 
//			{	//#if ${Usuario} == "T"
//				UsuarioComumEdicao uie = new UsuarioComumEdicao();
//				//#endif
//				final JDialog frame = new JDialog();
//				//#if ${Usuario} == "T"
//				uie.setDoneEvent(new ActionListener() 
//				
//				{
//					@Override
//					public void actionPerformed(ActionEvent e) 
//					{
//						frame.dispose();
//					}
//				});//#endif
//				frame.setModal(true);
//				frame.setResizable(false);
//				frame.setBounds(400, 200, 480, 480);
//				//#if ${Usuario} == "T"
//				frame.getContentPane().add(uie);
//				//#endif
//				frame.setVisible(true);
//			}
//		});
//		
//		panel.add(btnLogar);
//		panel.add(btnCadastrar);
//		dlgLogin.getContentPane().add(panel);
//		dlgLogin.setVisible(true);
//	}
	//#endif
	
}